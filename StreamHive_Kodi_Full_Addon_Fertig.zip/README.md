# StreamHive Kodi Add-on

StreamHive ist ein Kodi Add-on, das **alle Genres deutscher Filme und Serien bündelt**:

- Action
- Komödie
- Horror
- Liebesfilme
- Bollywood
- Kriegsfilme
- Animation / Familie
- Slasher
- Serien

Alle Inhalte sind **legal und deutsch synchronisiert**.

## Installation

1. Kodi öffnen
2. Add-ons → Aus ZIP-Datei installieren → URL einfügen
3. StreamHive Add-on starten

## Lizenz
Dieses Add-on ist unter der MIT License lizenziert.
